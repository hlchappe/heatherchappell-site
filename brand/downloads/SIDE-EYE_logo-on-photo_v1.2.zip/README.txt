SIDE EYE logo pack, version 1.2, November 24, 2026.

Primary logo: horizontal-tagline. "reverse" (cream and pink) goes on dark grounds.
"positive" (black and pink) goes on light grounds.
Version 1.1 added the approved stacked layouts (stacked and stacked-tagline).
Version 1.2 adds the small-size eye, for 24 px and under only (browser tabs, tiny app and menu icons).

1_screen         SVG and PNG for screens. Transparent unless the name says on-black or on-cream.
2_print          PDFs. Use pdf-cmyk for print (black is K100, pink is C0 M72 Y10 K0).
3_icons-avatars  App icon, social avatars, YouTube watermark, link preview image, small icon tiles (16, 20, 24 px).
4_web-favicons   Drop-in favicon set for a website. 16 and 24 px use the small-size eye.
5_on-photo       The logo on a solid Toner Black plate, for photos and busy frames.
eye-small        The small-size eye (30-unit outline). Use it only at 24 px and under, never larger.

Leave clear space of at least one iris width (the pink dot) on every side.
Never stretch, rotate, recolor, outline or add effects. Never redraw the logo or rebuild it in another font.
Never make a version of it with an AI image tool. Place these files.

Full rules and the "Which file do I use?" table are on the SIDE EYE Brand Standards page.
Check that page for a newer version before each new project. Uses not covered need approval (see LICENSE.txt).
