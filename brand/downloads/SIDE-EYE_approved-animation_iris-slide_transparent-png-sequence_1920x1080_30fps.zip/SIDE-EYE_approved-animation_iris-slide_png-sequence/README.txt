SIDE EYE approved logo animation: the iris slide.
90 frames, 30 fps, 1920x1080, transparent background.
The iris starts centered, slides right into its glance in 0.6 s, then holds. Use it as it is:
don't retime it, recolor it or loop the slide. Put it on Toner Black (#1A1A1A) or a dark solid field.
