Filled-eye mark, for merch on colored items only (stickers, mugs, pins, shirts and totes that are not white, cream or black).
The eye has a solid Toner Black inside, a cream outline and a Side Eye Pink iris.
On white or cream items, use the hollow positive files. On black items, use the reverse files.
Never use the filled eye on screens, in the magazine or in video.
The preview-on-red PNG only shows how it looks on a colored item. Don't print it.
