SIDE EYE logo pack, version 1.1, November 24, 2026.

Primary logo: horizontal-tagline. "reverse" (cream and pink) goes on dark grounds.
"positive" (black and pink) goes on light grounds.
Version 1.1 adds the approved stacked layouts (stacked and stacked-tagline).

1_screen         SVG and PNG for screens. Transparent unless the name says on-black or on-cream.
2_print          PDFs. Use pdf-cmyk for print (black is K100, pink is C0 M72 Y10 K0).
3_icons-avatars  App icon, social avatars, YouTube watermark, link preview image.
4_web-favicons   Drop-in favicon set for a website.
5_on-photo       The logo on a solid Toner Black plate, for photos and busy frames.

Leave clear space of at least one iris width (the pink dot) on every side.
Never stretch, rotate, recolor, outline or add effects. Never redraw the logo or rebuild it in another font.
Never make a version of it with an AI image tool. Place these files.

Full rules and the "Which file do I use?" table are on the SIDE EYE Brand Standards page.
Check that page for a newer version before each new project. Uses not covered need approval (see LICENSE.txt).
